package br.com.bibliotecadigital.decorator;

import java.util.List;

public class SeloDestaqueDecorator extends LivroDecorator {

    public SeloDestaqueDecorator(ItemBiblioteca item) {
        super(item);
    }

    @Override
    public String getDescricao() {
        return "[DESTAQUE] " + super.getDescricao();
    }

    @Override
    public List<String> getRecursos() {
        List<String> recursos = super.getRecursos();
        recursos.add("Destaque");
        return recursos;
    }
}
