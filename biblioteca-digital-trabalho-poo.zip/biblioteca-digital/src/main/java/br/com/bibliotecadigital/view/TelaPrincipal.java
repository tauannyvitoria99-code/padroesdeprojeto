package br.com.bibliotecadigital.view;

import br.com.bibliotecadigital.controller.BibliotecaController;
import br.com.bibliotecadigital.decorator.ItemBiblioteca;
import br.com.bibliotecadigital.model.Emprestimo;
import br.com.bibliotecadigital.model.Livro;
import br.com.bibliotecadigital.observer.BibliotecaObserver;
import br.com.bibliotecadigital.observer.EventoBiblioteca;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.time.format.DateTimeFormatter;
import java.util.Optional;

public class TelaPrincipal extends BorderPane implements BibliotecaObserver {
    private static final DateTimeFormatter FORMATO_DATA = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private final BibliotecaController controller;
    private final Stage stage;
    private final PainelHistorico painelHistorico = new PainelHistorico();

    private final TextField campoBusca = new TextField();
    private final ComboBox<String> comboStatus = new ComboBox<>();

    private final ObservableList<Livro> dadosLivros = FXCollections.observableArrayList();
    private final TableView<Livro> tabelaLivros = new TableView<>(dadosLivros);

    private final ObservableList<Emprestimo> dadosEmprestimos = FXCollections.observableArrayList();
    private final TableView<Emprestimo> tabelaEmprestimos = new TableView<>(dadosEmprestimos);
    private final CheckBox chkApenasAtivos = new CheckBox("Mostrar apenas empréstimos ativos");

    private final Label lblTotal = new Label("0");
    private final Label lblDisponiveis = new Label("0");
    private final Label lblEmprestados = new Label("0");
    private final Label lblUltimaNotificacao = new Label("Sistema pronto.");

    public TelaPrincipal(BibliotecaController controller, Stage stage) {
        this.controller = controller;
        this.stage = stage;

        this.controller.adicionarObserver(this);
        this.controller.adicionarObserver(painelHistorico);

        montarInterface();
        atualizarTabelasEResumo();
    }

    private void montarInterface() {
        setTop(criarCabecalho());

        TabPane abas = new TabPane();
        abas.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        Tab abaLivros = new Tab("Catálogo de Livros", criarAbaLivros());
        Tab abaEmprestimos = new Tab("Empréstimos", criarAbaEmprestimos());
        Tab abaNotificacoes = new Tab("Notificações", painelHistorico);

        abas.getTabs().addAll(abaLivros, abaEmprestimos, abaNotificacoes);
        setCenter(abas);
        setBottom(criarRodape());
    }

    private HBox criarCabecalho() {
        Label titulo = new Label("Biblioteca Digital");
        titulo.getStyleClass().add("titulo-sistema");

        Label subtitulo = new Label("Gestão de acervo, empréstimos e devoluções");
        subtitulo.getStyleClass().add("subtitulo-sistema");

        VBox blocoTitulo = new VBox(2, titulo, subtitulo);

        Region espacador = new Region();
        HBox.setHgrow(espacador, Priority.ALWAYS);

        VBox cardTotal = criarCardResumo("TOTAL DE LIVROS", lblTotal, "card-valor");
        VBox cardDisp = criarCardResumo("DISPONÍVEIS", lblDisponiveis, "card-valor-verde");
        VBox cardEmp = criarCardResumo("EMPRESTADOS", lblEmprestados, "card-valor-laranja");

        HBox topo = new HBox(14, blocoTitulo, espacador, cardTotal, cardDisp, cardEmp);
        topo.setAlignment(Pos.CENTER_LEFT);
        topo.getStyleClass().add("topo-barra");
        return topo;
    }

    private VBox criarCardResumo(String titulo, Label valor, String classeValor) {
        Label lblTitulo = new Label(titulo);
        lblTitulo.getStyleClass().add("card-titulo");
        valor.getStyleClass().add(classeValor);

        VBox card = new VBox(2, lblTitulo, valor);
        card.getStyleClass().add("card-resumo");
        return card;
    }

    private VBox criarAbaLivros() {
        campoBusca.setPromptText("Buscar por título, autor, categoria ou ISBN...");
        campoBusca.setPrefWidth(340);
        campoBusca.textProperty().addListener((obs, oldVal, newVal) -> carregarTabelaLivros());

        comboStatus.getItems().addAll("Todos", "Disponíveis", "Emprestados");
        comboStatus.setValue("Todos");
        comboStatus.setOnAction(e -> carregarTabelaLivros());

        Button btnLimpar = new Button("Limpar Filtros");
        btnLimpar.setOnAction(e -> {
            campoBusca.clear();
            comboStatus.setValue("Todos");
            carregarTabelaLivros();
        });

        HBox barraBusca = new HBox(10, new Label("Pesquisar:"), campoBusca, new Label("Status:"), comboStatus, btnLimpar);
        barraBusca.setAlignment(Pos.CENTER_LEFT);

        configurarTabelaLivros();
        VBox.setVgrow(tabelaLivros, Priority.ALWAYS);

        Button btnCadastrar = new Button("Cadastrar Livro");
        btnCadastrar.getStyleClass().add("btn-primario");
        btnCadastrar.setOnAction(e -> new DialogoLivro(stage, controller, null).showAndWait());

        Button btnEditar = new Button("Editar");
        btnEditar.setOnAction(e -> editarLivroSelecionado());

        Button btnRemover = new Button("Remover");
        btnRemover.getStyleClass().add("btn-perigo");
        btnRemover.setOnAction(e -> removerLivroSelecionado());

        Region espacador = new Region();
        HBox.setHgrow(espacador, Priority.ALWAYS);

        Button btnEmprestar = new Button("Emprestar");
        btnEmprestar.getStyleClass().add("btn-sucesso");
        btnEmprestar.setOnAction(e -> emprestarLivroSelecionado());

        Button btnDevolver = new Button("Devolver");
        btnDevolver.getStyleClass().add("btn-aviso");
        btnDevolver.setOnAction(e -> devolverLivroSelecionado());

        HBox barraAcoes = new HBox(10, btnCadastrar, btnEditar, btnRemover, espacador, btnEmprestar, btnDevolver);
        barraAcoes.setAlignment(Pos.CENTER_LEFT);

        VBox painel = new VBox(12, barraBusca, tabelaLivros, barraAcoes);
        painel.getStyleClass().add("painel-conteudo");
        return painel;
    }

    @SuppressWarnings("unchecked")
    private void configurarTabelaLivros() {
        TableColumn<Livro, Integer> colId = new TableColumn<>("ID");
        colId.setCellValueFactory(c -> new SimpleIntegerProperty(c.getValue().getId()).asObject());
        colId.setPrefWidth(48);

        TableColumn<Livro, String> colTitulo = new TableColumn<>("Título");
        colTitulo.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getTitulo()));
        colTitulo.setPrefWidth(220);

        TableColumn<Livro, String> colAutor = new TableColumn<>("Autor");
        colAutor.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getAutor()));
        colAutor.setPrefWidth(155);

        TableColumn<Livro, String> colCategoria = new TableColumn<>("Categoria");
        colCategoria.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getCategoria()));
        colCategoria.setPrefWidth(145);

        TableColumn<Livro, Integer> colAno = new TableColumn<>("Ano");
        colAno.setCellValueFactory(c -> new SimpleIntegerProperty(c.getValue().getAnoPublicacao()).asObject());
        colAno.setPrefWidth(62);

        TableColumn<Livro, String> colIsbn = new TableColumn<>("ISBN");
        colIsbn.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getIsbn()));
        colIsbn.setPrefWidth(125);

        TableColumn<Livro, String> colRecursos = new TableColumn<>("Recursos (Decorator)");
        colRecursos.setCellValueFactory(c -> {
            ItemBiblioteca item = controller.montarItemDecorado(c.getValue());
            String texto = item.getRecursos().isEmpty() ? "Padrão" : String.join(", ", item.getRecursos());
            return new SimpleStringProperty(texto);
        });
        colRecursos.setPrefWidth(165);

        TableColumn<Livro, String> colPrazo = new TableColumn<>("Prazo");
        colPrazo.setCellValueFactory(c -> {
            ItemBiblioteca item = controller.montarItemDecorado(c.getValue());
            return new SimpleStringProperty(item.getPrazoEmprestimoDias() + " dias");
        });
        colPrazo.setPrefWidth(72);

        TableColumn<Livro, String> colStatus = new TableColumn<>("Status");
        colStatus.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getStatus().getDescricao()));
        colStatus.setPrefWidth(95);

        tabelaLivros.getColumns().setAll(colId, colTitulo, colAutor, colCategoria, colAno, colIsbn, colRecursos, colPrazo, colStatus);
        tabelaLivros.setPlaceholder(new Label("Nenhum livro encontrado."));
    }

    private VBox criarAbaEmprestimos() {
        chkApenasAtivos.setSelected(true);
        chkApenasAtivos.setOnAction(e -> carregarTabelaEmprestimos());

        configurarTabelaEmprestimos();
        VBox.setVgrow(tabelaEmprestimos, Priority.ALWAYS);

        Button btnDevolver = new Button("Registrar Devolução");
        btnDevolver.getStyleClass().add("btn-aviso");
        btnDevolver.setOnAction(e -> devolverDaAbaEmprestimos());

        HBox barraAcoes = new HBox(10, btnDevolver);
        barraAcoes.setAlignment(Pos.CENTER_LEFT);

        VBox painel = new VBox(12, chkApenasAtivos, tabelaEmprestimos, barraAcoes);
        painel.getStyleClass().add("painel-conteudo");
        return painel;
    }

    @SuppressWarnings("unchecked")
    private void configurarTabelaEmprestimos() {
        TableColumn<Emprestimo, Integer> colId = new TableColumn<>("ID");
        colId.setCellValueFactory(c -> new SimpleIntegerProperty(c.getValue().getId()).asObject());
        colId.setPrefWidth(50);

        TableColumn<Emprestimo, String> colLivro = new TableColumn<>("Livro");
        colLivro.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getTituloLivro()));
        colLivro.setPrefWidth(220);

        TableColumn<Emprestimo, String> colLeitor = new TableColumn<>("Leitor");
        colLeitor.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getNomeLeitor()));
        colLeitor.setPrefWidth(155);

        TableColumn<Emprestimo, String> colEmail = new TableColumn<>("E-mail");
        colEmail.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getEmailLeitor()));
        colEmail.setPrefWidth(195);

        TableColumn<Emprestimo, String> colDataEmp = new TableColumn<>("Empréstimo");
        colDataEmp.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getDataEmprestimo().format(FORMATO_DATA)));
        colDataEmp.setPrefWidth(95);

        TableColumn<Emprestimo, String> colPrevista = new TableColumn<>("Previsão");
        colPrevista.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getDataPrevistaDevolucao().format(FORMATO_DATA)));
        colPrevista.setPrefWidth(95);

        TableColumn<Emprestimo, String> colDevolucao = new TableColumn<>("Devolução");
        colDevolucao.setCellValueFactory(c -> {
            String data = c.getValue().getDataDevolucao() == null
                    ? "-"
                    : c.getValue().getDataDevolucao().format(FORMATO_DATA);
            return new SimpleStringProperty(data);
        });
        colDevolucao.setPrefWidth(95);

        TableColumn<Emprestimo, String> colSituacao = new TableColumn<>("Situação");
        colSituacao.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getSituacao()));
        colSituacao.setPrefWidth(140);

        tabelaEmprestimos.getColumns().setAll(colId, colLivro, colLeitor, colEmail, colDataEmp, colPrevista, colDevolucao, colSituacao);
        tabelaEmprestimos.setPlaceholder(new Label("Nenhum empréstimo encontrado."));
    }

    private HBox criarRodape() {
        lblUltimaNotificacao.getStyleClass().add("texto-rodape");
        HBox rodape = new HBox(lblUltimaNotificacao);
        rodape.setAlignment(Pos.CENTER_LEFT);
        rodape.getStyleClass().add("rodape-barra");
        return rodape;
    }

    private Livro obterLivroSelecionado() {
        Livro selecionado = tabelaLivros.getSelectionModel().getSelectedItem();
        if (selecionado == null) {
            mostrarAlerta(Alert.AlertType.INFORMATION, "Aviso", "Selecione um livro na tabela.");
        }
        return selecionado;
    }

    private void editarLivroSelecionado() {
        Livro livro = obterLivroSelecionado();
        if (livro != null) {
            new DialogoLivro(stage, controller, livro).showAndWait();
        }
    }

    private void removerLivroSelecionado() {
        Livro livro = obterLivroSelecionado();
        if (livro == null) {
            return;
        }
        Alert confirmacao = new Alert(Alert.AlertType.CONFIRMATION);
        confirmacao.initOwner(stage);
        confirmacao.setTitle("Confirmar Remoção");
        confirmacao.setHeaderText(null);
        confirmacao.setContentText("Deseja remover o livro \"" + livro.getTitulo() + "\"?");

        Optional<ButtonType> resposta = confirmacao.showAndWait();
        if (resposta.isPresent() && resposta.get() == ButtonType.OK) {
            try {
                controller.removerLivro(livro.getId());
            } catch (IllegalArgumentException | IllegalStateException e) {
                mostrarAlerta(Alert.AlertType.WARNING, "Operação não permitida", e.getMessage());
            } catch (RuntimeException e) {
                mostrarAlerta(Alert.AlertType.ERROR, "Erro", "Erro ao remover: " + e.getMessage());
            }
        }
    }

    private void emprestarLivroSelecionado() {
        Livro livro = obterLivroSelecionado();
        if (livro != null) {
            new DialogoEmprestimo(stage, controller, livro).showAndWait();
        }
    }

    private void devolverLivroSelecionado() {
        Livro livro = obterLivroSelecionado();
        if (livro != null) {
            executarDevolucao(livro.getId());
        }
    }

    private void devolverDaAbaEmprestimos() {
        Emprestimo selecionado = tabelaEmprestimos.getSelectionModel().getSelectedItem();
        if (selecionado == null) {
            mostrarAlerta(Alert.AlertType.INFORMATION, "Aviso", "Selecione um empréstimo na tabela.");
            return;
        }
        executarDevolucao(selecionado.getLivroId());
    }

    private void executarDevolucao(int livroId) {
        try {
            Emprestimo devolvido = controller.registrarDevolucao(livroId);
            mostrarAlerta(Alert.AlertType.INFORMATION, "Devolução",
                    "Devolução concluída! Situação: " + devolvido.getSituacao());
        } catch (IllegalArgumentException | IllegalStateException e) {
            mostrarAlerta(Alert.AlertType.WARNING, "Aviso", e.getMessage());
        } catch (RuntimeException e) {
            mostrarAlerta(Alert.AlertType.ERROR, "Erro", "Erro ao devolver: " + e.getMessage());
        }
    }

    private void carregarTabelaLivros() {
        dadosLivros.setAll(controller.buscarLivros(campoBusca.getText(), comboStatus.getValue()));
    }

    private void carregarTabelaEmprestimos() {
        dadosEmprestimos.setAll(controller.listarEmprestimos(chkApenasAtivos.isSelected()));
    }

    private void atualizarTabelasEResumo() {
        carregarTabelaLivros();
        carregarTabelaEmprestimos();
        lblTotal.setText(String.valueOf(controller.contarTotalLivros()));
        lblDisponiveis.setText(String.valueOf(controller.contarDisponiveis()));
        lblEmprestados.setText(String.valueOf(controller.contarEmprestados()));
    }

    private void mostrarAlerta(Alert.AlertType tipo, String titulo, String mensagem) {
        Alert alert = new Alert(tipo);
        alert.initOwner(stage);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensagem);
        alert.showAndWait();
    }

    @Override
    public void atualizar(EventoBiblioteca evento) {
        atualizarTabelasEResumo();
        lblUltimaNotificacao.setText("Último evento: " + evento.getMensagem());
    }
}
