package br.com.bibliotecadigital.decorator;

import br.com.bibliotecadigital.model.Livro;
import java.util.List;

public interface ItemBiblioteca {
    Livro getLivro();
    String getDescricao();
    int getPrazoEmprestimoDias();
    List<String> getRecursos();
}
