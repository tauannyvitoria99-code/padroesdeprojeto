package br.com.bibliotecadigital.decorator;

import java.util.List;

public class PrazoEstendidoDecorator extends LivroDecorator {
    private static final int DIAS_EXTRAS = 7;

    public PrazoEstendidoDecorator(ItemBiblioteca item) {
        super(item);
    }

    @Override
    public int getPrazoEmprestimoDias() {
        return super.getPrazoEmprestimoDias() + DIAS_EXTRAS;
    }

    @Override
    public List<String> getRecursos() {
        List<String> recursos = super.getRecursos();
        recursos.add("Prazo +7d");
        return recursos;
    }
}
