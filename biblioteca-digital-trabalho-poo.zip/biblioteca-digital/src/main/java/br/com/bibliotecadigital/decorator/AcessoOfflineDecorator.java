package br.com.bibliotecadigital.decorator;

import java.util.List;

public class AcessoOfflineDecorator extends LivroDecorator {

    public AcessoOfflineDecorator(ItemBiblioteca item) {
        super(item);
    }

    @Override
    public String getDescricao() {
        return super.getDescricao() + " [Offline]";
    }

    @Override
    public List<String> getRecursos() {
        List<String> recursos = super.getRecursos();
        recursos.add("Offline");
        return recursos;
    }
}
