package br.com.bibliotecadigital.model;

public class Livro {
    private int id;
    private String titulo;
    private String autor;
    private String categoria;
    private int anoPublicacao;
    private String isbn;
    private StatusLivro status;
    private boolean destaque;
    private boolean acessoOffline;
    private boolean prazoEstendido;

    public Livro(int id, String titulo, String autor, String categoria, int anoPublicacao,
                 String isbn, StatusLivro status, boolean destaque,
                 boolean acessoOffline, boolean prazoEstendido) {
        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
        this.categoria = categoria;
        this.anoPublicacao = anoPublicacao;
        this.isbn = isbn;
        this.status = status;
        this.destaque = destaque;
        this.acessoOffline = acessoOffline;
        this.prazoEstendido = prazoEstendido;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public int getAnoPublicacao() {
        return anoPublicacao;
    }

    public void setAnoPublicacao(int anoPublicacao) {
        this.anoPublicacao = anoPublicacao;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public StatusLivro getStatus() {
        return status;
    }

    public void setStatus(StatusLivro status) {
        this.status = status;
    }

    public boolean isDestaque() {
        return destaque;
    }

    public void setDestaque(boolean destaque) {
        this.destaque = destaque;
    }

    public boolean isAcessoOffline() {
        return acessoOffline;
    }

    public void setAcessoOffline(boolean acessoOffline) {
        this.acessoOffline = acessoOffline;
    }

    public boolean isPrazoEstendido() {
        return prazoEstendido;
    }

    public void setPrazoEstendido(boolean prazoEstendido) {
        this.prazoEstendido = prazoEstendido;
    }

    @Override
    public String toString() {
        return titulo + " (" + autor + ")";
    }
}
