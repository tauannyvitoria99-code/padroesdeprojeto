package br.com.bibliotecadigital.repository;

import br.com.bibliotecadigital.model.Emprestimo;
import br.com.bibliotecadigital.model.Livro;
import br.com.bibliotecadigital.model.StatusLivro;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class BibliotecaRepository {
    private static BibliotecaRepository instancia;

    private final Path pastaDados;
    private final Path arquivoLivros;
    private final Path arquivoEmprestimos;

    private final List<Livro> livros;
    private final List<Emprestimo> emprestimos;
    private int proximoIdLivro;
    private int proximoIdEmprestimo;

    private BibliotecaRepository() {
        this.pastaDados = Paths.get("dados");
        this.arquivoLivros = pastaDados.resolve("livros.csv");
        this.arquivoEmprestimos = pastaDados.resolve("emprestimos.csv");
        this.livros = new ArrayList<>();
        this.emprestimos = new ArrayList<>();
        this.proximoIdLivro = 1;
        this.proximoIdEmprestimo = 1;

        inicializarArquivos();
        carregarLivros();
        carregarEmprestimos();
    }

    public static synchronized BibliotecaRepository getInstance() {
        if (instancia == null) {
            instancia = new BibliotecaRepository();
        }
        return instancia;
    }

    private void inicializarArquivos() {
        try {
            if (!Files.exists(pastaDados)) {
                Files.createDirectories(pastaDados);
            }
            if (!Files.exists(arquivoLivros)) {
                try (BufferedWriter writer = Files.newBufferedWriter(arquivoLivros, StandardCharsets.UTF_8)) {
                    writer.write("id;titulo;autor;categoria;anoPublicacao;isbn;status;destaque;acessoOffline;prazoEstendido");
                    writer.newLine();
                }
            }
            if (!Files.exists(arquivoEmprestimos)) {
                try (BufferedWriter writer = Files.newBufferedWriter(arquivoEmprestimos, StandardCharsets.UTF_8)) {
                    writer.write("id;livroId;tituloLivro;nomeLeitor;emailLeitor;dataEmprestimo;dataPrevistaDevolucao;dataDevolucao");
                    writer.newLine();
                }
            }
        } catch (IOException e) {
            throw new RuntimeException("Erro ao inicializar arquivos de dados: " + e.getMessage(), e);
        }
    }

    private void carregarLivros() {
        livros.clear();
        int maiorId = 0;
        try (BufferedReader reader = Files.newBufferedReader(arquivoLivros, StandardCharsets.UTF_8)) {
            String linha = reader.readLine();
            while ((linha = reader.readLine()) != null) {
                if (linha.trim().isEmpty()) {
                    continue;
                }
                String[] partes = linha.split(";", -1);
                if (partes.length < 10) {
                    continue;
                }
                int id = Integer.parseInt(partes[0].trim());
                String titulo = partes[1].trim();
                String autor = partes[2].trim();
                String categoria = partes[3].trim();
                int ano = Integer.parseInt(partes[4].trim());
                String isbn = partes[5].trim();
                StatusLivro status = StatusLivro.valueOf(partes[6].trim());
                boolean destaque = Boolean.parseBoolean(partes[7].trim());
                boolean acessoOffline = Boolean.parseBoolean(partes[8].trim());
                boolean prazoEstendido = Boolean.parseBoolean(partes[9].trim());

                livros.add(new Livro(id, titulo, autor, categoria, ano, isbn, status,
                        destaque, acessoOffline, prazoEstendido));
                if (id > maiorId) {
                    maiorId = id;
                }
            }
        } catch (IOException | RuntimeException e) {
            throw new RuntimeException("Erro ao carregar livros.csv: " + e.getMessage(), e);
        }
        proximoIdLivro = maiorId + 1;
    }

    private void carregarEmprestimos() {
        emprestimos.clear();
        int maiorId = 0;
        try (BufferedReader reader = Files.newBufferedReader(arquivoEmprestimos, StandardCharsets.UTF_8)) {
            String linha = reader.readLine();
            while ((linha = reader.readLine()) != null) {
                if (linha.trim().isEmpty()) {
                    continue;
                }
                String[] partes = linha.split(";", -1);
                if (partes.length < 8) {
                    continue;
                }
                int id = Integer.parseInt(partes[0].trim());
                int livroId = Integer.parseInt(partes[1].trim());
                String tituloLivro = partes[2].trim();
                String nomeLeitor = partes[3].trim();
                String emailLeitor = partes[4].trim();
                LocalDate dataEmprestimo = LocalDate.parse(partes[5].trim());
                LocalDate dataPrevista = LocalDate.parse(partes[6].trim());
                LocalDate dataDevolucao = partes[7].trim().isEmpty() ? null : LocalDate.parse(partes[7].trim());

                emprestimos.add(new Emprestimo(id, livroId, tituloLivro, nomeLeitor,
                        emailLeitor, dataEmprestimo, dataPrevista, dataDevolucao));
                if (id > maiorId) {
                    maiorId = id;
                }
            }
        } catch (IOException | RuntimeException e) {
            throw new RuntimeException("Erro ao carregar emprestimos.csv: " + e.getMessage(), e);
        }
        proximoIdEmprestimo = maiorId + 1;
    }

    private void gravarLivros() {
        try (BufferedWriter writer = Files.newBufferedWriter(arquivoLivros, StandardCharsets.UTF_8)) {
            writer.write("id;titulo;autor;categoria;anoPublicacao;isbn;status;destaque;acessoOffline;prazoEstendido");
            writer.newLine();
            for (Livro livro : livros) {
                writer.write(livro.getId() + ";"
                        + limparCampo(livro.getTitulo()) + ";"
                        + limparCampo(livro.getAutor()) + ";"
                        + limparCampo(livro.getCategoria()) + ";"
                        + livro.getAnoPublicacao() + ";"
                        + limparCampo(livro.getIsbn()) + ";"
                        + livro.getStatus().name() + ";"
                        + livro.isDestaque() + ";"
                        + livro.isAcessoOffline() + ";"
                        + livro.isPrazoEstendido());
                writer.newLine();
            }
        } catch (IOException e) {
            throw new RuntimeException("Erro ao salvar livros.csv: " + e.getMessage(), e);
        }
    }

    private void gravarEmprestimos() {
        try (BufferedWriter writer = Files.newBufferedWriter(arquivoEmprestimos, StandardCharsets.UTF_8)) {
            writer.write("id;livroId;tituloLivro;nomeLeitor;emailLeitor;dataEmprestimo;dataPrevistaDevolucao;dataDevolucao");
            writer.newLine();
            for (Emprestimo emp : emprestimos) {
                String devolucao = emp.getDataDevolucao() == null ? "" : emp.getDataDevolucao().toString();
                writer.write(emp.getId() + ";"
                        + emp.getLivroId() + ";"
                        + limparCampo(emp.getTituloLivro()) + ";"
                        + limparCampo(emp.getNomeLeitor()) + ";"
                        + limparCampo(emp.getEmailLeitor()) + ";"
                        + emp.getDataEmprestimo() + ";"
                        + emp.getDataPrevistaDevolucao() + ";"
                        + devolucao);
                writer.newLine();
            }
        } catch (IOException e) {
            throw new RuntimeException("Erro ao salvar emprestimos.csv: " + e.getMessage(), e);
        }
    }

    private String limparCampo(String valor) {
        if (valor == null) {
            return "";
        }
        return valor.replace(";", ",").replace("\r", " ").replace("\n", " ").trim();
    }

    public List<Livro> listarLivros() {
        return new ArrayList<>(livros);
    }

    public Optional<Livro> buscarLivroPorId(int id) {
        for (Livro livro : livros) {
            if (livro.getId() == id) {
                return Optional.of(livro);
            }
        }
        return Optional.empty();
    }

    public Livro salvarLivro(Livro livro) {
        if (livro.getId() == 0) {
            livro.setId(proximoIdLivro++);
            livros.add(livro);
        } else {
            boolean atualizado = false;
            for (int i = 0; i < livros.size(); i++) {
                if (livros.get(i).getId() == livro.getId()) {
                    livros.set(i, livro);
                    atualizado = true;
                    break;
                }
            }
            if (!atualizado) {
                livros.add(livro);
            }
        }
        gravarLivros();
        return livro;
    }

    public boolean removerLivro(int id) {
        boolean removido = livros.removeIf(l -> l.getId() == id);
        if (removido) {
            gravarLivros();
        }
        return removido;
    }

    public List<Emprestimo> listarEmprestimos() {
        return new ArrayList<>(emprestimos);
    }

    public Optional<Emprestimo> buscarEmprestimoAtivoPorLivro(int livroId) {
        for (Emprestimo emp : emprestimos) {
            if (emp.getLivroId() == livroId && emp.isAtivo()) {
                return Optional.of(emp);
            }
        }
        return Optional.empty();
    }

    public Emprestimo salvarEmprestimo(Emprestimo emprestimo) {
        if (emprestimo.getId() == 0) {
            emprestimo.setId(proximoIdEmprestimo++);
            emprestimos.add(emprestimo);
        } else {
            boolean atualizado = false;
            for (int i = 0; i < emprestimos.size(); i++) {
                if (emprestimos.get(i).getId() == emprestimo.getId()) {
                    emprestimos.set(i, emprestimo);
                    atualizado = true;
                    break;
                }
            }
            if (!atualizado) {
                emprestimos.add(emprestimo);
            }
        }
        gravarEmprestimos();
        return emprestimo;
    }

    public String getCaminhoPastaDados() {
        return pastaDados.toAbsolutePath().toString();
    }
}
