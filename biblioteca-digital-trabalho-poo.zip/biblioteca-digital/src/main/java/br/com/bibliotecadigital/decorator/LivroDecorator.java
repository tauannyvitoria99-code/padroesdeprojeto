package br.com.bibliotecadigital.decorator;

import br.com.bibliotecadigital.model.Livro;
import java.util.List;

public abstract class LivroDecorator implements ItemBiblioteca {
    protected final ItemBiblioteca item;

    public LivroDecorator(ItemBiblioteca item) {
        this.item = item;
    }

    @Override
    public Livro getLivro() {
        return item.getLivro();
    }

    @Override
    public String getDescricao() {
        return item.getDescricao();
    }

    @Override
    public int getPrazoEmprestimoDias() {
        return item.getPrazoEmprestimoDias();
    }

    @Override
    public List<String> getRecursos() {
        return item.getRecursos();
    }
}
