package br.com.bibliotecadigital.app;

import br.com.bibliotecadigital.controller.BibliotecaController;
import br.com.bibliotecadigital.view.TelaPrincipal;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.net.URL;

public class BibliotecaApp extends Application {

    public static void iniciar(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {
        BibliotecaController controller = new BibliotecaController();
        TelaPrincipal telaPrincipal = new TelaPrincipal(controller, stage);

        Scene scene = new Scene(telaPrincipal, 1120, 680);
        URL css = getClass().getResource("/style.css");
        if (css != null) {
            scene.getStylesheets().add(css.toExternalForm());
        }

        stage.setTitle("Biblioteca Digital");
        stage.setMinWidth(960);
        stage.setMinHeight(580);
        stage.setScene(scene);
        stage.show();
    }
}
