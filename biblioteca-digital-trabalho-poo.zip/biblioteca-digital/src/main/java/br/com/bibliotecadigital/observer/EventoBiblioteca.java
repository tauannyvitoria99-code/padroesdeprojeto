package br.com.bibliotecadigital.observer;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class EventoBiblioteca {
    public enum Tipo {
        CADASTRO,
        EDICAO,
        REMOCAO,
        EMPRESTIMO,
        DEVOLUCAO
    }

    private static final DateTimeFormatter FORMATO_HORA = DateTimeFormatter.ofPattern("HH:mm:ss");

    private final Tipo tipo;
    private final String mensagem;
    private final LocalDateTime dataHora;

    public EventoBiblioteca(Tipo tipo, String mensagem) {
        this.tipo = tipo;
        this.mensagem = mensagem;
        this.dataHora = LocalDateTime.now();
    }

    public Tipo getTipo() {
        return tipo;
    }

    public String getMensagem() {
        return mensagem;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    public String getHorarioFormatado() {
        return dataHora.format(FORMATO_HORA);
    }
}
