package br.com.bibliotecadigital.view;

import br.com.bibliotecadigital.controller.BibliotecaController;
import br.com.bibliotecadigital.decorator.ItemBiblioteca;
import br.com.bibliotecadigital.model.Livro;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.net.URL;

public class DialogoEmprestimo extends Stage {
    private final BibliotecaController controller;
    private final Livro livro;

    private final TextField campoLeitor = new TextField();
    private final TextField campoEmail = new TextField();

    public DialogoEmprestimo(Stage owner, BibliotecaController controller, Livro livro) {
        this.controller = controller;
        this.livro = livro;

        initOwner(owner);
        initModality(Modality.APPLICATION_MODAL);
        setTitle("Registrar Empréstimo");
        setResizable(false);

        montarInterface();
    }

    private void montarInterface() {
        ItemBiblioteca item = controller.montarItemDecorado(livro);

        Label lblTitulo = new Label("Novo Empréstimo");
        lblTitulo.getStyleClass().add("dialogo-titulo");

        Label lblItem = new Label(item.getDescricao());
        lblItem.setStyle("-fx-font-weight: bold; -fx-text-fill: #1E293B;");
        lblItem.setWrapText(true);
        lblItem.setMaxWidth(360);

        Label lblPrazo = new Label("Prazo calculado: " + item.getPrazoEmprestimoDias() + " dias");
        lblPrazo.setStyle("-fx-text-fill: #059669; -fx-font-weight: bold;");

        VBox resumoLivro = new VBox(4, lblItem, lblPrazo);
        resumoLivro.getStyleClass().add("secao-box");

        campoLeitor.setPrefWidth(270);
        campoEmail.setPrefWidth(270);

        GridPane grid = new GridPane();
        grid.setHgap(12);
        grid.setVgap(10);
        grid.add(new Label("Nome do Leitor:"), 0, 0);
        grid.add(campoLeitor, 1, 0);
        grid.add(new Label("E-mail do Leitor:"), 0, 1);
        grid.add(campoEmail, 1, 1);

        Button btnCancelar = new Button("Cancelar");
        btnCancelar.setOnAction(e -> close());

        Button btnConfirmar = new Button("Confirmar Empréstimo");
        btnConfirmar.getStyleClass().add("btn-sucesso");
        btnConfirmar.setOnAction(e -> confirmar());

        HBox botoes = new HBox(10, btnCancelar, btnConfirmar);
        botoes.setAlignment(Pos.CENTER_RIGHT);
        botoes.setPadding(new Insets(6, 0, 0, 0));

        VBox raiz = new VBox(14, lblTitulo, resumoLivro, grid, botoes);
        raiz.getStyleClass().add("dialogo-raiz");

        Scene scene = new Scene(raiz);
        URL css = getClass().getResource("/style.css");
        if (css != null) {
            scene.getStylesheets().add(css.toExternalForm());
        }
        setScene(scene);
    }

    private void confirmar() {
        try {
            controller.realizarEmprestimo(livro.getId(), campoLeitor.getText(), campoEmail.getText());
            close();
        } catch (IllegalArgumentException | IllegalStateException e) {
            mostrarAlerta(Alert.AlertType.WARNING, "Validação", e.getMessage());
        } catch (RuntimeException e) {
            mostrarAlerta(Alert.AlertType.ERROR, "Erro", "Erro ao registrar empréstimo: " + e.getMessage());
        }
    }

    private void mostrarAlerta(Alert.AlertType tipo, String titulo, String mensagem) {
        Alert alert = new Alert(tipo);
        alert.initOwner(this);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensagem);
        alert.showAndWait();
    }
}
