package br.com.bibliotecadigital.decorator;

import br.com.bibliotecadigital.model.Livro;
import java.util.ArrayList;
import java.util.List;

public class LivroBase implements ItemBiblioteca {
    private static final int PRAZO_PADRAO_DIAS = 7;
    private final Livro livro;

    public LivroBase(Livro livro) {
        this.livro = livro;
    }

    @Override
    public Livro getLivro() {
        return livro;
    }

    @Override
    public String getDescricao() {
        return livro.getTitulo() + " - " + livro.getAutor();
    }

    @Override
    public int getPrazoEmprestimoDias() {
        return PRAZO_PADRAO_DIAS;
    }

    @Override
    public List<String> getRecursos() {
        return new ArrayList<>();
    }
}
