package br.com.bibliotecadigital.view;

import br.com.bibliotecadigital.controller.BibliotecaController;
import br.com.bibliotecadigital.model.Livro;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.net.URL;

public class DialogoLivro extends Stage {
    private final BibliotecaController controller;
    private final Livro livroEdicao;

    private final TextField campoTitulo = new TextField();
    private final TextField campoAutor = new TextField();
    private final TextField campoCategoria = new TextField();
    private final TextField campoAno = new TextField();
    private final TextField campoIsbn = new TextField();

    private final CheckBox chkDestaque = new CheckBox("Selo de Destaque");
    private final CheckBox chkOffline = new CheckBox("Acesso Offline");
    private final CheckBox chkPrazoEstendido = new CheckBox("Prazo Estendido (+7 dias no empréstimo)");

    public DialogoLivro(Stage owner, BibliotecaController controller, Livro livroEdicao) {
        this.controller = controller;
        this.livroEdicao = livroEdicao;

        initOwner(owner);
        initModality(Modality.APPLICATION_MODAL);
        setTitle(livroEdicao == null ? "Cadastrar Livro" : "Editar Livro");
        setResizable(false);

        montarInterface();
        preencherCamposSeEdicao();
    }

    private void montarInterface() {
        Label lblTituloJanela = new Label(livroEdicao == null ? "Novo Livro" : "Editar Livro");
        lblTituloJanela.getStyleClass().add("dialogo-titulo");

        campoTitulo.setPrefWidth(290);
        campoAutor.setPrefWidth(290);
        campoCategoria.setPrefWidth(290);
        campoAno.setPrefWidth(120);
        campoIsbn.setPrefWidth(200);

        GridPane grid = new GridPane();
        grid.setHgap(12);
        grid.setVgap(10);

        grid.add(new Label("Título:"), 0, 0);
        grid.add(campoTitulo, 1, 0);

        grid.add(new Label("Autor:"), 0, 1);
        grid.add(campoAutor, 1, 1);

        grid.add(new Label("Categoria:"), 0, 2);
        grid.add(campoCategoria, 1, 2);

        grid.add(new Label("Ano de Publicação:"), 0, 3);
        grid.add(campoAno, 1, 3);

        grid.add(new Label("ISBN:"), 0, 4);
        grid.add(campoIsbn, 1, 4);

        Label lblRecursos = new Label("Recursos Digitais (Decorator)");
        lblRecursos.setStyle("-fx-font-weight: bold; -fx-text-fill: #334155;");

        VBox boxRecursos = new VBox(8, lblRecursos, chkDestaque, chkOffline, chkPrazoEstendido);
        boxRecursos.getStyleClass().add("secao-box");

        Button btnCancelar = new Button("Cancelar");
        btnCancelar.setOnAction(e -> close());

        Button btnSalvar = new Button("Salvar");
        btnSalvar.getStyleClass().add("btn-primario");
        btnSalvar.setOnAction(e -> salvar());

        HBox botoes = new HBox(10, btnCancelar, btnSalvar);
        botoes.setAlignment(Pos.CENTER_RIGHT);
        botoes.setPadding(new Insets(6, 0, 0, 0));

        VBox raiz = new VBox(14, lblTituloJanela, grid, boxRecursos, botoes);
        raiz.getStyleClass().add("dialogo-raiz");

        Scene scene = new Scene(raiz);
        URL css = getClass().getResource("/style.css");
        if (css != null) {
            scene.getStylesheets().add(css.toExternalForm());
        }
        setScene(scene);
    }

    private void preencherCamposSeEdicao() {
        if (livroEdicao != null) {
            campoTitulo.setText(livroEdicao.getTitulo());
            campoAutor.setText(livroEdicao.getAutor());
            campoCategoria.setText(livroEdicao.getCategoria());
            campoAno.setText(String.valueOf(livroEdicao.getAnoPublicacao()));
            campoIsbn.setText(livroEdicao.getIsbn());
            chkDestaque.setSelected(livroEdicao.isDestaque());
            chkOffline.setSelected(livroEdicao.isAcessoOffline());
            chkPrazoEstendido.setSelected(livroEdicao.isPrazoEstendido());
        }
    }

    private void salvar() {
        int ano;
        try {
            ano = Integer.parseInt(campoAno.getText().trim());
        } catch (NumberFormatException e) {
            mostrarAlerta(Alert.AlertType.WARNING, "Entrada inválida", "Informe um número válido para o ano.");
            return;
        }

        try {
            if (livroEdicao == null) {
                controller.cadastrarLivro(
                        campoTitulo.getText(),
                        campoAutor.getText(),
                        campoCategoria.getText(),
                        ano,
                        campoIsbn.getText(),
                        chkDestaque.isSelected(),
                        chkOffline.isSelected(),
                        chkPrazoEstendido.isSelected()
                );
            } else {
                controller.editarLivro(
                        livroEdicao.getId(),
                        campoTitulo.getText(),
                        campoAutor.getText(),
                        campoCategoria.getText(),
                        ano,
                        campoIsbn.getText(),
                        chkDestaque.isSelected(),
                        chkOffline.isSelected(),
                        chkPrazoEstendido.isSelected()
                );
            }
            close();
        } catch (IllegalArgumentException | IllegalStateException e) {
            mostrarAlerta(Alert.AlertType.WARNING, "Validação", e.getMessage());
        } catch (RuntimeException e) {
            mostrarAlerta(Alert.AlertType.ERROR, "Erro", "Erro ao salvar: " + e.getMessage());
        }
    }

    private void mostrarAlerta(Alert.AlertType tipo, String titulo, String mensagem) {
        Alert alert = new Alert(tipo);
        alert.initOwner(this);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensagem);
        alert.showAndWait();
    }
}
