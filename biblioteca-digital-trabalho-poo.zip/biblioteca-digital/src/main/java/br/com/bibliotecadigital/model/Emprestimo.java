package br.com.bibliotecadigital.model;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Emprestimo {
    private int id;
    private int livroId;
    private String tituloLivro;
    private String nomeLeitor;
    private String emailLeitor;
    private LocalDate dataEmprestimo;
    private LocalDate dataPrevistaDevolucao;
    private LocalDate dataDevolucao;

    public Emprestimo(int id, int livroId, String tituloLivro, String nomeLeitor,
                      String emailLeitor, LocalDate dataEmprestimo,
                      LocalDate dataPrevistaDevolucao, LocalDate dataDevolucao) {
        this.id = id;
        this.livroId = livroId;
        this.tituloLivro = tituloLivro;
        this.nomeLeitor = nomeLeitor;
        this.emailLeitor = emailLeitor;
        this.dataEmprestimo = dataEmprestimo;
        this.dataPrevistaDevolucao = dataPrevistaDevolucao;
        this.dataDevolucao = dataDevolucao;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getLivroId() {
        return livroId;
    }

    public void setLivroId(int livroId) {
        this.livroId = livroId;
    }

    public String getTituloLivro() {
        return tituloLivro;
    }

    public void setTituloLivro(String tituloLivro) {
        this.tituloLivro = tituloLivro;
    }

    public String getNomeLeitor() {
        return nomeLeitor;
    }

    public void setNomeLeitor(String nomeLeitor) {
        this.nomeLeitor = nomeLeitor;
    }

    public String getEmailLeitor() {
        return emailLeitor;
    }

    public void setEmailLeitor(String emailLeitor) {
        this.emailLeitor = emailLeitor;
    }

    public LocalDate getDataEmprestimo() {
        return dataEmprestimo;
    }

    public void setDataEmprestimo(LocalDate dataEmprestimo) {
        this.dataEmprestimo = dataEmprestimo;
    }

    public LocalDate getDataPrevistaDevolucao() {
        return dataPrevistaDevolucao;
    }

    public void setDataPrevistaDevolucao(LocalDate dataPrevistaDevolucao) {
        this.dataPrevistaDevolucao = dataPrevistaDevolucao;
    }

    public LocalDate getDataDevolucao() {
        return dataDevolucao;
    }

    public void setDataDevolucao(LocalDate dataDevolucao) {
        this.dataDevolucao = dataDevolucao;
    }

    public boolean isAtivo() {
        return dataDevolucao == null;
    }

    public long getDiasAtraso() {
        LocalDate referencia = isAtivo() ? LocalDate.now() : dataDevolucao;
        long dias = ChronoUnit.DAYS.between(dataPrevistaDevolucao, referencia);
        return Math.max(0, dias);
    }

    public String getSituacao() {
        long atraso = getDiasAtraso();
        if (!isAtivo()) {
            return atraso > 0 ? "Devolvido (" + atraso + "d atraso)" : "Devolvido";
        }
        return atraso > 0 ? "Atrasado (" + atraso + "d)" : "Em andamento";
    }
}
