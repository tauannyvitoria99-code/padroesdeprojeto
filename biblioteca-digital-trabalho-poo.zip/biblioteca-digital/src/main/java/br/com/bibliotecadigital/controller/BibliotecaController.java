package br.com.bibliotecadigital.controller;

import br.com.bibliotecadigital.decorator.AcessoOfflineDecorator;
import br.com.bibliotecadigital.decorator.ItemBiblioteca;
import br.com.bibliotecadigital.decorator.LivroBase;
import br.com.bibliotecadigital.decorator.PrazoEstendidoDecorator;
import br.com.bibliotecadigital.decorator.SeloDestaqueDecorator;
import br.com.bibliotecadigital.model.Emprestimo;
import br.com.bibliotecadigital.model.Livro;
import br.com.bibliotecadigital.model.StatusLivro;
import br.com.bibliotecadigital.observer.BibliotecaObserver;
import br.com.bibliotecadigital.observer.BibliotecaSubject;
import br.com.bibliotecadigital.observer.EventoBiblioteca;
import br.com.bibliotecadigital.repository.BibliotecaRepository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class BibliotecaController implements BibliotecaSubject {
    private final BibliotecaRepository repository;
    private final List<BibliotecaObserver> observers;

    public BibliotecaController() {
        this.repository = BibliotecaRepository.getInstance();
        this.observers = new ArrayList<>();
    }

    @Override
    public void adicionarObserver(BibliotecaObserver observer) {
        if (observer != null && !observers.contains(observer)) {
            observers.add(observer);
        }
    }

    @Override
    public void removerObserver(BibliotecaObserver observer) {
        observers.remove(observer);
    }

    @Override
    public void notificarObservers(EventoBiblioteca evento) {
        for (BibliotecaObserver observer : observers) {
            observer.atualizar(evento);
        }
    }

    public ItemBiblioteca montarItemDecorado(Livro livro) {
        ItemBiblioteca item = new LivroBase(livro);
        if (livro.isDestaque()) {
            item = new SeloDestaqueDecorator(item);
        }
        if (livro.isAcessoOffline()) {
            item = new AcessoOfflineDecorator(item);
        }
        if (livro.isPrazoEstendido()) {
            item = new PrazoEstendidoDecorator(item);
        }
        return item;
    }

    public List<Livro> listarLivros() {
        return repository.listarLivros();
    }

    public Optional<Livro> buscarLivroPorId(int id) {
        return repository.buscarLivroPorId(id);
    }

    public List<Livro> buscarLivros(String termo, String filtroStatus) {
        String busca = termo == null ? "" : termo.trim().toLowerCase();
        List<Livro> resultado = new ArrayList<>();

        for (Livro livro : repository.listarLivros()) {
            boolean bateStatus = true;
            if ("Disponíveis".equals(filtroStatus)) {
                bateStatus = livro.getStatus() == StatusLivro.DISPONIVEL;
            } else if ("Emprestados".equals(filtroStatus)) {
                bateStatus = livro.getStatus() == StatusLivro.EMPRESTADO;
            }

            if (!bateStatus) {
                continue;
            }

            if (busca.isEmpty()
                    || livro.getTitulo().toLowerCase().contains(busca)
                    || livro.getAutor().toLowerCase().contains(busca)
                    || livro.getCategoria().toLowerCase().contains(busca)
                    || livro.getIsbn().toLowerCase().contains(busca)) {
                resultado.add(livro);
            }
        }
        return resultado;
    }

    public Livro cadastrarLivro(String titulo, String autor, String categoria, int anoPublicacao,
                                String isbn, boolean destaque, boolean acessoOffline,
                                boolean prazoEstendido) {
        validarDadosLivro(titulo, autor, categoria, anoPublicacao, isbn, 0);

        Livro novo = new Livro(0, titulo.trim(), autor.trim(), categoria.trim(), anoPublicacao,
                isbn.trim(), StatusLivro.DISPONIVEL, destaque, acessoOffline, prazoEstendido);
        repository.salvarLivro(novo);

        ItemBiblioteca item = montarItemDecorado(novo);
        notificarObservers(new EventoBiblioteca(EventoBiblioteca.Tipo.CADASTRO,
                "Livro cadastrado: " + item.getDescricao()));
        return novo;
    }

    public Livro editarLivro(int id, String titulo, String autor, String categoria, int anoPublicacao,
                             String isbn, boolean destaque, boolean acessoOffline,
                             boolean prazoEstendido) {
        Livro existente = repository.buscarLivroPorId(id)
                .orElseThrow(() -> new IllegalArgumentException("Livro não encontrado."));

        validarDadosLivro(titulo, autor, categoria, anoPublicacao, isbn, id);

        existente.setTitulo(titulo.trim());
        existente.setAutor(autor.trim());
        existente.setCategoria(categoria.trim());
        existente.setAnoPublicacao(anoPublicacao);
        existente.setIsbn(isbn.trim());
        existente.setDestaque(destaque);
        existente.setAcessoOffline(acessoOffline);
        existente.setPrazoEstendido(prazoEstendido);

        repository.salvarLivro(existente);
        notificarObservers(new EventoBiblioteca(EventoBiblioteca.Tipo.EDICAO,
                "Livro atualizado: " + existente.getTitulo()));
        return existente;
    }

    public void removerLivro(int id) {
        Livro livro = repository.buscarLivroPorId(id)
                .orElseThrow(() -> new IllegalArgumentException("Livro não encontrado."));

        if (livro.getStatus() == StatusLivro.EMPRESTADO) {
            throw new IllegalStateException("Não é possível remover um livro que está emprestado.");
        }

        repository.removerLivro(id);
        notificarObservers(new EventoBiblioteca(EventoBiblioteca.Tipo.REMOCAO,
                "Livro removido: " + livro.getTitulo()));
    }

    public Emprestimo realizarEmprestimo(int livroId, String nomeLeitor, String emailLeitor) {
        if (nomeLeitor == null || nomeLeitor.trim().isEmpty()) {
            throw new IllegalArgumentException("Informe o nome do leitor.");
        }
        if (emailLeitor == null || !emailLeitor.trim().contains("@")) {
            throw new IllegalArgumentException("Informe um e-mail válido para o leitor.");
        }

        Livro livro = repository.buscarLivroPorId(livroId)
                .orElseThrow(() -> new IllegalArgumentException("Livro não encontrado."));

        if (livro.getStatus() == StatusLivro.EMPRESTADO) {
            throw new IllegalStateException("Este livro já está emprestado.");
        }

        ItemBiblioteca item = montarItemDecorado(livro);
        int prazoDias = item.getPrazoEmprestimoDias();
        LocalDate hoje = LocalDate.now();
        LocalDate prevista = hoje.plusDays(prazoDias);

        livro.setStatus(StatusLivro.EMPRESTADO);
        repository.salvarLivro(livro);

        Emprestimo emprestimo = new Emprestimo(0, livro.getId(), livro.getTitulo(),
                nomeLeitor.trim(), emailLeitor.trim(), hoje, prevista, null);
        repository.salvarEmprestimo(emprestimo);

        notificarObservers(new EventoBiblioteca(EventoBiblioteca.Tipo.EMPRESTIMO,
                "Empréstimo de \"" + livro.getTitulo() + "\" para " + nomeLeitor.trim()
                        + " (prazo: " + prazoDias + " dias, devolução até " + prevista + ")"));
        return emprestimo;
    }

    public Emprestimo registrarDevolucao(int livroId) {
        Livro livro = repository.buscarLivroPorId(livroId)
                .orElseThrow(() -> new IllegalArgumentException("Livro não encontrado."));

        Emprestimo emprestimo = repository.buscarEmprestimoAtivoPorLivro(livroId)
                .orElseThrow(() -> new IllegalStateException("Não há empréstimo ativo para este livro."));

        emprestimo.setDataDevolucao(LocalDate.now());
        repository.salvarEmprestimo(emprestimo);

        livro.setStatus(StatusLivro.DISPONIVEL);
        repository.salvarLivro(livro);

        long atraso = emprestimo.getDiasAtraso();
        String detalhe = atraso > 0
                ? " com " + atraso + " dia(s) de atraso"
                : " dentro do prazo";

        notificarObservers(new EventoBiblioteca(EventoBiblioteca.Tipo.DEVOLUCAO,
                "Devolução registrada: \"" + livro.getTitulo() + "\" (" + emprestimo.getNomeLeitor() + ")" + detalhe));
        return emprestimo;
    }

    public List<Emprestimo> listarEmprestimos(boolean apenasAtivos) {
        List<Emprestimo> todos = repository.listarEmprestimos();
        if (!apenasAtivos) {
            return todos;
        }
        List<Emprestimo> ativos = new ArrayList<>();
        for (Emprestimo emp : todos) {
            if (emp.isAtivo()) {
                ativos.add(emp);
            }
        }
        return ativos;
    }

    public int contarTotalLivros() {
        return repository.listarLivros().size();
    }

    public int contarDisponiveis() {
        int total = 0;
        for (Livro livro : repository.listarLivros()) {
            if (livro.getStatus() == StatusLivro.DISPONIVEL) {
                total++;
            }
        }
        return total;
    }

    public int contarEmprestados() {
        return contarTotalLivros() - contarDisponiveis();
    }

    private void validarDadosLivro(String titulo, String autor, String categoria,
                                   int anoPublicacao, String isbn, int idIgnorado) {
        if (titulo == null || titulo.trim().isEmpty()) {
            throw new IllegalArgumentException("O título do livro é obrigatório.");
        }
        if (autor == null || autor.trim().isEmpty()) {
            throw new IllegalArgumentException("O autor do livro é obrigatório.");
        }
        if (categoria == null || categoria.trim().isEmpty()) {
            throw new IllegalArgumentException("A categoria do livro é obrigatória.");
        }
        int anoAtual = LocalDate.now().getYear();
        if (anoPublicacao < 1450 || anoPublicacao > anoAtual + 1) {
            throw new IllegalArgumentException("Informe um ano de publicação entre 1450 e " + (anoAtual + 1) + ".");
        }
        if (isbn == null || isbn.trim().length() < 5) {
            throw new IllegalArgumentException("Informe um ISBN válido.");
        }
        for (Livro outro : repository.listarLivros()) {
            if (outro.getId() != idIgnorado && outro.getIsbn().equalsIgnoreCase(isbn.trim())) {
                throw new IllegalArgumentException("Já existe um livro cadastrado com o ISBN " + isbn.trim() + ".");
            }
        }
    }
}
