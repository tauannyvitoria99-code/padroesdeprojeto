package br.com.bibliotecadigital.observer;

public interface BibliotecaObserver {
    void atualizar(EventoBiblioteca evento);
}
