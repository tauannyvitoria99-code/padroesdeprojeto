package br.com.bibliotecadigital.app;

public class Main {
    public static void main(String[] args) {
        BibliotecaApp.iniciar(args);
    }
}
