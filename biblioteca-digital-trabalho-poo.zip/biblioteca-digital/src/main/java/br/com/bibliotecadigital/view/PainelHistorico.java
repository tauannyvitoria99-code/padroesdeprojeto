package br.com.bibliotecadigital.view;

import br.com.bibliotecadigital.observer.BibliotecaObserver;
import br.com.bibliotecadigital.observer.EventoBiblioteca;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

public class PainelHistorico extends VBox implements BibliotecaObserver {
    private final ObservableList<String> eventos = FXCollections.observableArrayList();
    private final ListView<String> listaEventos = new ListView<>(eventos);

    public PainelHistorico() {
        setSpacing(10);
        getStyleClass().add("painel-conteudo");

        Label titulo = new Label("Eventos recentes do sistema (padrão Observer)");
        titulo.setStyle("-fx-font-weight: bold; -fx-font-size: 14px; -fx-text-fill: #1E3A5F;");

        Region espacador = new Region();
        HBox.setHgrow(espacador, Priority.ALWAYS);

        Button btnLimpar = new Button("Limpar Histórico");
        btnLimpar.setOnAction(e -> eventos.clear());

        HBox topo = new HBox(10, titulo, espacador, btnLimpar);
        topo.setAlignment(Pos.CENTER_LEFT);

        listaEventos.setPlaceholder(new Label("Nenhuma notificação registrada nesta sessão."));
        VBox.setVgrow(listaEventos, Priority.ALWAYS);

        getChildren().addAll(topo, listaEventos);
    }

    @Override
    public void atualizar(EventoBiblioteca evento) {
        String linha = String.format("[%s] [%s] %s",
                evento.getHorarioFormatado(),
                evento.getTipo().name(),
                evento.getMensagem());
        eventos.add(0, linha);
    }
}
