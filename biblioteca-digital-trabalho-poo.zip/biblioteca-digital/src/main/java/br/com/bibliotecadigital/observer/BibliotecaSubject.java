package br.com.bibliotecadigital.observer;

public interface BibliotecaSubject {
    void adicionarObserver(BibliotecaObserver observer);
    void removerObserver(BibliotecaObserver observer);
    void notificarObservers(EventoBiblioteca evento);
}
